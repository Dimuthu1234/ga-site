<footer id="colophon" class="site-footer2" role="contentinfo">
    <div class="site-info container">
        © 2018 | G A Installation & Maintenance Ltd | All Rights Reserved | <a href="https://www.decode.lk/" target="_blank" rel="noopener">DeCODE</a>
        | <img class="footer-logo" src="<?php echo e(url('/images/iso-3.png')); ?>"/>
    </div><!-- .site-info -->
</footer><!-- #colophon -->